const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const jwt = require('jsonwebtoken');
//const expressJwt = require('express-jwt');
const sql = require('mssql');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');

const secretKey = 'C6TsEigF1OxSPdy9mOGeeJTkyBJh4Krw';

const app = express();
const port = 3001; 

app.use(cors());
app.use(bodyParser.json());

const MSSQL_USER = process.env.MSSQL_USER;
const MSSQL_PASSWORD = process.env.MSSQL_PASSWORD;
const MSSQL_SERVER = process.env.MSSQL_SERVER;
const MSSQL_DATABASE = process.env.MSSQL_DATABASE;

// Database URL
const dbUrl = `jdbc:sqlserver://${MSSQL_SERVER}:1433;database=${MSSQL_DATABASE}`;

// Configuration object for the SQL Server connection
const config = {
  user: MSSQL_USER,
  password: MSSQL_PASSWORD,
  server: 'db',
  database: MSSQL_DATABASE,
  port: 1433,
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 15000,
    enableArithAbort: true,
  },
  url: dbUrl,
};

sql.connect(config)
  .then(pool => {
    console.log('Connected to the database');
  })
  .catch(err => {
    console.error('Error connecting to MS SQL Server:', err);
  });

// Middleware to generate a JWT token for a user
function generateToken(user) {
    return jwt.sign({ sub: user.id, username: user.username }, secretKey, { expiresIn: '1h' });
}

const authenticateJWT = (req, res, next) => {
  const authorizationHeader = req.headers.authorization;

  if (!authorizationHeader) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const token = authorizationHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, secretKey);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};


const getUserStockHoldings = async (userId) => {
  // Perform a SQL query to fetch user's stock holdings
  const result = await sql.query`
    SELECT s.ticker, s.stock_name, ush.quantity, s.stock_id
    FROM user_stock_holdings ush
    INNER JOIN stocks s ON ush.stock_id = s.stock_id
    WHERE ush.user_id = ${userId}
  `;
  return result.recordset;
};

// Sample route to get user's stock holdings
app.get('/favorites', authenticateJWT, async (req, res) => {
  console.log('Fetching user stock holdings');
  const userId = req.user.sub; // Assuming user ID is stored in the request object (you may need to adjust this based on your authentication setup)
  try {
    const stockHoldings = await getUserStockHoldings(userId);
    console.log(stockHoldings);
    res.json(stockHoldings);
  } catch (error) {
    console.error('Error fetching user stock holdings:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/register', async (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  try {
      console.log('Registering user:', email);

      const hashedPassword = await bcrypt.hash(password, 10);
      await sql.query`INSERT INTO users (email, password) VALUES (${email}, ${hashedPassword})`;
      // Send a success response
      res.status(200).json({ message: 'User registered successfully' });
  } catch (error) {
      console.error('Error registering user:', error);
      res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/signin', async (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  try {
      console.log('Attempting to sign in user:', email);

      const hashedPassword = await bcrypt.hash(password, 10);

      // Query the database to find the user by email and password
      const result = await sql.query`SELECT * FROM users WHERE email = ${email}`;

      // Check if a user with the given credentials was found
      if (result.recordset.length > 0) {
        const hashedPasswordOriginal = result.recordset[0].password;

        // Compare the provided password with the hashed password from the database
        const passwordMatch = await bcrypt.compare(password, hashedPasswordOriginal);
  
        if (passwordMatch) {
          // User authenticated, send a success response
          user = {
            id: result.recordset[0].user_id,
            username: result.recordset[0].email
          }
          const token = generateToken(user);
          res.status(200).json({ token });
        } else {
          // Password does not match, send an error response
          res.status(401).json({ error: 'Invalid credentials' });
        }
      } else {
          // No user found with the given credentials, send an error response
          res.status(401).json({ error: 'Invalid credentials' });
      }
  } catch (error) {
      console.error('Error signing in user:', error);
      res.status(500).json({ error: 'Internal Server Error' });
  }
});




//https://query1.finance.yahoo.com/v8/finance/chart/AAPL?metrics=high?&interval=1d&range=10d
// Define a route to handle stock data requests
app.get('/stock/:ticker', async (req, res) => {
    const ticker = req.params.ticker;

    try {
        const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?metrics=high?&interval=1d&range=10d`;
        const response = await fetch(url);

        if (!response.ok) {
            return res.status(response.status).send(response.statusText);
        }

        const data = await response.json();

        const financialData = data.chart.result[0].indicators.quote[0];

        currency = data.chart.result[0].meta.currency;
        regularMarketPrice = data.chart.result[0].meta.regularMarketPrice;
        exchangeName = data.chart.result[0].meta.exchangeName;
        openPrices = data.chart.result[0].indicators.quote[0].open;
        closePrices = data.chart.result[0].indicators.quote[0].close;
        highPrices = data.chart.result[0].indicators.quote[0].high;
        lowPrices = data.chart.result[0].indicators.quote[0].low;
        volumes = data.chart.result[0].indicators.quote[0].volume;

        if (financialData && financialData.close) {
            const currentPrice = financialData.close[financialData.close.length - 1];

            res.send({
                symbol: ticker,
                exchangeName: exchangeName,
                currency: currency,
                currentPrice: currentPrice,
                regularMarketPrice: regularMarketPrice,
                open: openPrices,
                close: closePrices,
                high: highPrices,
                low: lowPrices,
                volume: volumes
            });
        } else {
            return res.status(404).send('Not found');
        }
    } catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Endpoint to add data to user_stock_holdings table
app.post('/addToStockHoldings', authenticateJWT, async (req, res) => {
  const { stockTicker, quantity, exchangeName } = req.body;
  const userId = req.user.sub;
  let stockId =0;
  console.log(req.body);
  // Validate input
  if (!stockTicker || !quantity || isNaN(quantity) || quantity <= 0) {
      return res.status(400).json({ message: 'Invalid input. Please provide a valid stock ticker and quantity.' });
  }

  try {
      // Check if the stock exists in the stocks table
      const stockResult = await sql.query`SELECT stock_id FROM stocks WHERE ticker = ${stockTicker}`;
      if (stockResult.recordset.length === 0) {
        await sql.query`INSERT INTO stocks (ticker,stock_name) VALUES (${stockTicker},${exchangeName})`;
        stockId = await sql.query`SELECT stock_id FROM stocks WHERE ticker = ${stockTicker}`;
        stockId = stockId.recordset[0].stock_id;
      }
      else{
        stockId = stockResult.recordset[0].stock_id;
      }

      const quantityNumber = Number(quantity);

      // Insert into user_stock_holdings table
      await sql.query`INSERT INTO user_stock_holdings (user_id, stock_id, quantity) VALUES (${userId},${stockId},${quantityNumber})`;

      return res.status(200).json({ message: 'Stock added to holdings successfully.' });
  } catch (error) {
      console.error('Error adding to stock holdings:', error);
      return res.status(500).json({ message: 'Internal server error.' });
  }
});

app.put('/update',authenticateJWT, async (req, res) => {
  const { stock_id, quantity } = req.body;
  const userId = req.user.sub;

  await sql.query`
            UPDATE user_stock_holdings
            SET quantity = ${quantity}
            WHERE user_id = ${userId} AND stock_id = ${stock_id}`;
  console.log("user" + userId + "stock" + stock_id + "quantity" + quantity);
  // if (!stock_id) {
  //     return res.status(404).send('Stock not found');
  // }

  // Respond with updated data
  return res.status(200).json({ message: 'Stock quantity updated succesfully.' });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

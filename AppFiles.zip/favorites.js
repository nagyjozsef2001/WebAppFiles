document.addEventListener('DOMContentLoaded', function () {

    const registrationLink = document.getElementById('registrationLink');
    const signInLink = document.getElementById('signInLink');
    const signoutLink = document.getElementById('signout');

    // Check if the JWT token is present in localStorage
    const jwtToken = localStorage.getItem('jwtToken');

    if (jwtToken) {
        // User is signed in, hide the "Registration" link
        registrationLink.style.display = 'none';
        signInLink.style.display = 'none';
    }
    else{
        signoutLink.style.display = 'none';
    }

    signoutLink.addEventListener('click', function (event) {
        // Prevent the default link behavior (e.g., navigating to a new page)
        event.preventDefault();

        // Remove the JWT token from localStorage
        localStorage.removeItem('jwtToken');

        // Redirect the user to the sign-in page
        window.location.href = 'login.html';
    });

    console.log(localStorage.getItem('jwtToken'));
    header= {
        headers: {
            'Authorization' :  `Bearer ${localStorage.getItem('jwtToken')}`,
            'Content-Type': 'application/json',
            'Connection': 'keep-alive'
        }
    };
    fetch('http://localhost:3001/favorites', header).then(response => response.json())
        .then(data => {
            // Populate the table with stock holdings
            console.log(data);
            const tableBody = document.querySelector('#stockHoldingsTable tbody');

            data.forEach(stock => {
                const row = tableBody.insertRow();
                row.insertCell(0).textContent = stock.ticker;
                row.insertCell(1).textContent = stock.stock_name;
                row.insertCell(2).textContent = stock.quantity;

                // Add number input field
                const quantityInput = document.createElement('input');
                quantityInput.type = 'number';
                quantityInput.min = 0;
                row.insertCell(3).appendChild(quantityInput);

                // Add send button
                const sendButton = document.createElement('button');
                sendButton.textContent = 'Send';
                sendButton.onclick = function() {
                    const quantity = quantityInput.value;
                    sendData(stock.ticker, stock.stock_id, quantity);
                };
                row.insertCell(4).appendChild(sendButton);
            });
        })
        .catch(error => {
            console.error('Error fetching user stock holdings:', error);
        });

        function sendData(ticker, stock_id, quantity) {
            // Construct the data payload
            console.log("stock_id: " + stock_id + " quantityfrfr: " + quantity + " ticker: " + ticker);
            const data = {
                ticker: ticker,
                stock_id: stock_id,
                quantity: quantity,
            };
        
            // Configure the request
            const requestOptions = {
                method: 'PUT', // Assuming you are using a PUT request for updates
                headers: {
                    'Authorization' :  `Bearer ${localStorage.getItem('jwtToken')}`,
                    'Content-Type': 'application/json',
                    'Connection': 'keep-alive'
                },
                body: JSON.stringify(data)
            };
        
            // Make the update request
            fetch('http://localhost:3001/update', requestOptions)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to update stock quantity');
                    }
                    console.log('Stock quantity updated successfully');
                })
                .catch(error => {
                    console.error('Error updating stock quantity:', error);
                });
            window.location.reload();
        }        
});

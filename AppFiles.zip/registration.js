document.addEventListener('DOMContentLoaded', function () {
    // Get the registration form element
    const registrationForm = document.getElementById('registrationForm');

    // Add event listener to the registration form on submit
    registrationForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Get the input values
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const passwordAgain = document.getElementById('passwordAgain').value;

        // Perform client-side validation (you can add more validation as needed)
        if (password !== passwordAgain) {
            alert("Passwords do not match. Please try again.");
            return;
        }

        // Send data to the server using fetch
        fetch('http://localhost:3001/register', {
            method: 'POST',
            body: JSON.stringify({
                email: email,
                password: password
            }),
            headers: {
                'Accept': 'application/json',
                'Content-type': 'application/json; charset=UTF-8',
                'Connection': 'keep-alive'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            // If the response is successful, log it or handle it accordingly
            console.log('Registration successful');
            window.location.href = 'index.html';
        })
        .then(data => {
            // Handle the response from the server as needed
            console.log('Server response:', data);
        })
        .catch(error => {
            console.error('Error sending data to the server:', error);
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {

    const registrationLink = document.getElementById('registrationLink');

    // Check if the JWT token is present in localStorage
    const jwtToken = localStorage.getItem('jwtToken');

    if (jwtToken) {
        // User is signed in, hide the "Registration" link
        registrationLink.style.display = 'none';
    }

    const signInForm = document.getElementById('signInForm');

    // Add event listener to the sign-in form on submit
    signInForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Get the input values
        const signInEmail = document.getElementById('signInEmail').value;
        const signInPassword = document.getElementById('signInPassword').value;

        // Perform client-side validation (you can add more validation as needed)

        // Send data to the server using fetch
        fetch('http://backendapi/signin', {
            method: 'POST',
            body: JSON.stringify({
                email: signInEmail,
                password: signInPassword
            }),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json; charset=UTF-8',
                'Connection': 'keep-alive'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.token) {
                // Store the token securely (you can use localStorage or sessionStorage)
                localStorage.setItem('jwtToken', data.token);

                // Log the successful sign-in and token
                console.log('Sign In successful');
                console.log('JWT Token:', data.token);

                // Redirect to index.html
                window.location.href = 'index.html';

            } else {
                console.log('Sign In failed');
            }
        })
        .catch(error => {
            console.error('Error sending data to the server:', error);
        });
    });
});

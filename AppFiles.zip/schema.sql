USE master;
GO
-- Create the database if not exists
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'stock_app')
    CREATE DATABASE stock_app;
GO

-- Switch to the created database
USE stock_app;
GO

-- Create the users table
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'users')
BEGIN
    CREATE TABLE users (
        user_id INT IDENTITY(1,1) PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL
    );
END

-- Create the stocks table
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'stocks')
BEGIN
    CREATE TABLE stocks (
        stock_id INT IDENTITY(1,1) PRIMARY KEY,
        ticker VARCHAR(10) UNIQUE NOT NULL,
        stock_name VARCHAR(255) NOT NULL
    );
END

-- Create a table to store user stock holdings
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'user_stock_holdings')
BEGIN
    CREATE TABLE user_stock_holdings (
        user_id INT,
        stock_id INT,
        quantity INT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (stock_id) REFERENCES stocks(stock_id)
    );
END

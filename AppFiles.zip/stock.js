async function searchStock() {
    const stockTicker = document.getElementById("stock-ticker").value;
    try {
        const response = await fetch(`backendapi/stock/${stockTicker}`);
        const data = await response.json();

        const closingPrices = data['close']; // Extract closing prices array

        // Calculate SMA
        const sma = closingPrices.reduce((sum, price) => sum + price, 0) / closingPrices.length;

        // Calculate EMA
        const alpha = 2 / (closingPrices.length + 1);
        let ema = closingPrices[0]; // Initial EMA value
        for (let i = 1; i < closingPrices.length; i++) {
            ema = (closingPrices[i] - ema) * alpha + ema;
        }

        // Calculate MACD (using 12-day and 26-day EMAs)
        const twelveDayEMA = closingPrices.slice(0, 12).reduce((sum, price) => sum + price, 0) / 12;
        const twentySixDayEMA = closingPrices.slice(0, 26).reduce((sum, price) => sum + price, 0) / 26;
        const macd = twelveDayEMA - twentySixDayEMA;

        // Calculate RSI
        let avgUpwardPriceChange = 0;
        let avgDownwardPriceChange = 0;
        for (let i = 1; i < closingPrices.length; i++) {
            const priceChange = closingPrices[i] - closingPrices[i - 1];
            if (priceChange > 0) {
                avgUpwardPriceChange += priceChange;
            } else {
                avgDownwardPriceChange -= priceChange;
            }
        }
        avgUpwardPriceChange /= closingPrices.length - 1;
        avgDownwardPriceChange /= closingPrices.length - 1;
        const RS = avgUpwardPriceChange / avgDownwardPriceChange;
        const rsi = 100 - (100 / (1 + RS));

        // Output results
        // console.log('SMA:', sma.toFixed(4));
        // console.log('EMA:', ema.toFixed(4));
        // console.log('MACD:', macd.toFixed(4));
        // console.log('RSI:', rsi.toFixed(4));



        // Update the stock-info section with the received data
        const stockInfoElement = document.getElementById("stock-info");
        if (data) {
            let htmlContent = `<p id="stock-ticker">Stock Ticker: ${data.symbol}</p>`;
            htmlContent = `<p id="exchange-name">Exchange name: ${data.exchangeName}</p>`;
            htmlContent += `<p>Currency: ${data.currency}</p>`;
            htmlContent += `<p>Current Price: ${data.currentPrice.toFixed(4)}</p>`;
            htmlContent += `<p>Regular Market Price: ${data.regularMarketPrice.toFixed(4)}</p>`;
            htmlContent += `<p>SMA: ${sma.toFixed(4)}</p>`;
            htmlContent += `<p>EMA: ${ema.toFixed(4)}</p>`;
            htmlContent += `<p>MACD: ${macd.toFixed(4)}</p>`;
            htmlContent += `<p>RSI: ${rsi.toFixed(4)}</p>`;
            htmlContent += "<div class='tableContainer'>";

            // Assuming openPrices, highPrices, lowPrices, closePrices, volumes are arrays of numeric values
            const priceTypes = ['Open', 'High', 'Low', 'Close', 'Volume'];
            htmlContent += "<table class='stock-table'>";
            htmlContent += `<thead><tr><th>Open Price</th><th>High Price</th><th>Low Price</th><th>Close Price</th><th>Volume</th></tr></thead>`;
            htmlContent += "<tbody>";
            // Iterate over the length of one of the price arrays (assuming they have the same length)
            for (let i = 0; i < data.open.length; i++) {
                htmlContent += "<tr>";
        
                priceTypes.forEach((priceType) => {
                    const price = data[priceType.toLowerCase()][i];
                    const roundedPrice = price.toFixed(4);
                    htmlContent += `<td>${roundedPrice}</td>`;
                });
        
                htmlContent += "</tr>";
            }
            htmlContent += "</tbody></table>";
            htmlContent += "</div>";
            exchangeName = data.exchangeName;
            const jwtToken = localStorage.getItem('jwtToken');
            // Add input field and button for adding to stock holdings
            if(jwtToken){
                htmlContent += "<label for='quantity'>Quantity:</label>";
                htmlContent += "<input type='number' id='quantity' placeholder='Enter quantity'>";
                htmlContent += "<button onclick='addToStockHoldings(exchangeName)'>Add to Stock Holdings</button>";
            }
            stockInfoElement.innerHTML = htmlContent;
        } else {
            stockInfoElement.innerHTML = "<p>No data available for this stock.</p>";
        }
    } catch (error) {
        console.error('Error fetching stock data:', error);
    }
}

async function addToStockHoldings(exchangeName) {
    const stockTicker = document.getElementById("stock-ticker").value;
    const quantity = document.getElementById("quantity").value;

    if (!stockTicker || !quantity || isNaN(quantity) || quantity <= 0 || !exchangeName) {
        alert("Please enter a valid stock ticker and quantity.");
        return;
    }

    try {
        console.log(exchangeName);
        const response = await fetch(`backendapi/addToStockHoldings`, {
            method: 'POST',
            headers: {
                'Authorization' :  `Bearer ${localStorage.getItem('jwtToken')}`,
                'Content-Type': 'application/json',
                'Connection': 'keep-alive'
            },
            body: JSON.stringify({
                stockTicker,
                quantity,
                exchangeName,
            }),
        });

        const result = await response.json();
        console.log(result);
        alert(result.message); // Display a success or error message
    } catch (error) {
        console.error('Error adding to stock holdings:', error);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const registrationLink = document.getElementById('registrationLink');
    const signInLink = document.getElementById('signInLink');
    const signoutLink = document.getElementById('signout');

    // Check if the JWT token is present in localStorage
    const jwtToken = localStorage.getItem('jwtToken');

    if (jwtToken) {
        // User is signed in, hide the "Registration" link
        registrationLink.style.display = 'none';
        signInLink.style.display = 'none';
    }
    else{
        signoutLink.style.display = 'none';
    }

    signoutLink.addEventListener('click', function (event) {
        // Prevent the default link behavior (e.g., navigating to a new page)
        event.preventDefault();

        // Remove the JWT token from localStorage
        localStorage.removeItem('jwtToken');

        // Redirect the user to the sign-in page
        window.location.href = 'login.html';
    });
});

-- Assuming 'my_database' is the name of your database
USE master;
GO

CREATE LOGIN stockAppLogin WITH PASSWORD = 'stockAppLogin';

-- Use the target database
USE stock_app;
GO

-- Create a user in the database associated with the login
CREATE USER stockAppUser FOR LOGIN stockAppLogin;
#!/bin/bash

# Check if public_ip.txt exists
echo `pwd`
if [ ! -f /usr/share/nginx/html/public_ip.txt ]; then
    echo "Error: public_ip.txt not found"
    exit 1
fi

# Get public IP from public_ip.txt
public_ip=$(</usr/share/nginx/html/public_ip.txt)
public_ip_clean=$(echo "$public_ip:3001" | tr -cd '[:print:]')
# Loop through all .js files in the current directory
sed -i "s/backendapi/$public_ip_clean/g" /usr/share/nginx/html/stock.js
sed -i "s/backendapi/$public_ip_clean/g" /usr/share/nginx/html/signin.js
sed -i "s/backendapi/$public_ip_clean/g" /usr/share/nginx/html/registration.js
sed -i "s/backendapi/$public_ip_clean/g" /usr/share/nginx/html/favorites.js


echo "Script finished"
